'''
Path
'''
#!/usr/bin/env python



'''
XMLRPC client / server example
reference: http://docs.python.org/library/simplexmlrpcserver.html
'''


import xmlrpclib

s = xmlrpclib.ServerProxy('http://localhost:8000')
print s.load()

# Print list of available methods
#print s.system.listMethods()

