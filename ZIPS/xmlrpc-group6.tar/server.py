#!/usr/bin/env python

'''
XMLRPC client / server example
reference: http://docs.python.org/library/simplexmlrpcserver.html
'''

from SimpleXMLRPCServer import SimpleXMLRPCServer
from SimpleXMLRPCServer import SimpleXMLRPCRequestHandler
import os

# Restrict to a particular path.
class RequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/RPC2',)

# Create server
server = SimpleXMLRPCServer(("localhost", 8000),
                            requestHandler=RequestHandler)
server.register_introspection_functions()

def get_load():
    return os.getloadavg()
server.register_function(get_load, 'load')

# Run the server's main loop
server.serve_forever()

