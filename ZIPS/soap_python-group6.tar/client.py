#!/usr/bin/env python

from SOAPpy import *

server_port = '8080'

def get_load(url):
    server = SOAPProxy(url)
    ipaddress = server.hello()
    print ipaddress;

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "usage:", str(sys.argv[0]), "remote_host"
        sys.exit()
    else:
        host = str(sys.argv[1])
        url = 'http://' + host + ':' + server_port + '/'
    get_load(url)

