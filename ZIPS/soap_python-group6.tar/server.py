#!/usr/bin/env python

from SOAPpy import *
import os

def hello(_SOAPContext = None):
    return "Average load: " + str(os.getloadavg())

if __name__ == "__main__":
  server = SOAPServer( ( '', 8080 ) )
  server.registerFunction( MethodSig(hello, keywords=0, context=1) )
  server.serve_forever()

