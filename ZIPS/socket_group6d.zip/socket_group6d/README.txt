
Socket client / server example

Sample client / server execution

1. First start the server,
        ./server.py

2. Then run the client,
        ./client.py

Note: 
The host address is set to 127.0.0.1 and it can be changed in the client.py file.

References:
http://docs.python.org/library/socket.html

We have used os.getloadavg() function to calculate the processor load.

