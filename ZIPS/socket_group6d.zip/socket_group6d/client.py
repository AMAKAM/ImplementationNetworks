#!/usr/bin/env python

'''
Client / server example
reference: http://docs.python.org/library/socket.html
'''

import socket
HOST = '127.0.0.1'    
PORT = 50007          
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
flag = True

print "Choose an option from the menu: "
print "1. Print processor load"
print "2. Exit"

while flag:
	cmd = raw_input("Choose a number: ")
	if int(cmd) == 1:
		s.send(cmd)
		data = s.recv(1024)
		print 'Received ', data
	elif int(cmd) == 2:
		s.send(cmd)
		flag = False
s.close()

