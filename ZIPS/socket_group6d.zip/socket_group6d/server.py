#!/usr/bin/env python

'''
Client / server example
reference: http://docs.python.org/library/socket.html
'''

import socket,os
HOST = ''                 
PORT = 50007              

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)

while True:
	conn, addr = s.accept()
	print 'Connected to by', addr
	while True:
		data = conn.recv(1024)
		if not data: continue
		if int(data) == 1:
			my_random = str(os.getloadavg())
			print 'Sending ', my_random
			conn.send(my_random)
		if int(data) == 2:
			break

conn.close()

